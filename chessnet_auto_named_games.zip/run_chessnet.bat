@echo off
setlocal EnableExtensions

cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python was not found.
    echo Install Python 3.10+ and check "Add Python to PATH" during install.
    pause
    exit /b 1
)

if not exist .venv (
    echo First run: creating local virtual environment...
    python -m venv .venv
    if errorlevel 1 goto :fail
)

call .venv\Scripts\activate.bat
if errorlevel 1 goto :fail

for /f "usebackq delims=" %%H in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Test-Path 'requirements.txt') { (Get-FileHash 'requirements.txt' -Algorithm SHA256).Hash }"`) do set "REQ_HASH=%%H"
set "HASH_FILE=.venv\.requirements_hash"
set "OLD_HASH="
if exist "%HASH_FILE%" set /p OLD_HASH=<"%HASH_FILE%"

if not exist "%HASH_FILE%" goto :install_requirements
if /I not "%REQ_HASH%"=="%OLD_HASH%" goto :install_requirements
goto :run_app

:install_requirements
echo Installing/updating ChessNet requirements...
python -m pip install --upgrade pip
if errorlevel 1 goto :fail
python -m pip install -r requirements.txt
if errorlevel 1 goto :fail
>"%HASH_FILE%" echo %REQ_HASH%

:run_app
python main.py
exit /b 0

:fail
echo.
echo ERROR: Could not start ChessNet. Review the messages above.
echo.
pause
exit /b 1
