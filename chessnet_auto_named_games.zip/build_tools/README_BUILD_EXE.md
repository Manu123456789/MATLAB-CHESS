# Building the Windows ChessNet App

ChessNet now uses a fast-launch PyInstaller **onedir** build instead of a slow
single-file executable.

## Why onedir?

PySide6/Qt applications bundle many DLLs and plugins. A single-file PyInstaller
EXE must unpack those files to a temporary folder every launch, which can make
startup feel slow. The onedir build keeps those files unpacked next to the EXE,
so Windows can load them directly.

## Build

From the project root, double-click:

```bat
build_windows_exe.bat
```

The script will:

1. Create/use `.venv` for building.
2. Install Python dependencies into that build environment.
3. Run PyInstaller in onedir mode.
4. Copy the built app folder to:

```text
%LOCALAPPDATA%\ChessNet
```

5. Create a Desktop shortcut:

```text
ChessNet.lnk
```

## Runtime behavior

The installed app does **not** run `pip`, create a virtual environment, or check
`requirements.txt` at startup. It launches from:

```text
%LOCALAPPDATA%\ChessNet\ChessNet.exe
```

The Desktop item is a shortcut pointing to that executable.

## Source launcher

`run_chessnet.bat` is still available for source/developer usage. It installs
requirements only on first run or when `requirements.txt` changes.
