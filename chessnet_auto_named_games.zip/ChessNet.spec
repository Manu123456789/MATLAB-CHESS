# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec for the fast-launch ChessNet Windows app.

This intentionally builds in one-folder (onedir) mode instead of one-file
mode. For a PySide6/Qt app, onedir starts much faster because Qt DLLs and
plugins remain unpacked on disk instead of being extracted to a temp directory
on every launch.

Build from the project root with:
    pyinstaller --clean --noconfirm ChessNet.spec

Output:
    dist/ChessNet/ChessNet.exe
"""

from PyInstaller.utils.hooks import collect_submodules

block_cipher = None

# PyInstaller's PySide6 hooks already discover the Qt modules/plugins imported
# by the application. Do not collect every PySide6 submodule; that greatly
# increases bundle size and startup/antivirus scanning time.
hiddenimports = []
hiddenimports += collect_submodules('chess')


a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[],
    datas=[('assets', 'assets')],
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'tests',
        'pytest',
        'unittest',
        'tkinter',
        'matplotlib',
        'numpy',
        'pandas',
        'scipy',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='ChessNet',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='ChessNet',
)
