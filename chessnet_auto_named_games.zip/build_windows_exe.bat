@echo off
setlocal EnableExtensions

cd /d "%~dp0"

echo ============================================================
echo Building fast-launch ChessNet Windows app
echo ============================================================
echo.
echo This build uses PyInstaller ONEDIR mode for faster startup.
echo It installs the app folder to:
echo   %%LOCALAPPDATA%%\ChessNet
echo and creates a Desktop shortcut:
echo   ChessNet.lnk
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python was not found.
    echo Install Python 3.10+ and check "Add Python to PATH" during install.
    pause
    exit /b 1
)

if not exist .venv (
    echo Creating local build virtual environment...
    python -m venv .venv
    if errorlevel 1 goto :fail
)

call .venv\Scripts\activate.bat
if errorlevel 1 goto :fail

echo Installing/updating build dependencies...
python -m pip install --upgrade pip
if errorlevel 1 goto :fail
python -m pip install -r requirements.txt
if errorlevel 1 goto :fail
python -m pip install -r requirements-build.txt
if errorlevel 1 goto :fail

echo.
echo Building one-folder app with PyInstaller...
pyinstaller --clean --noconfirm ChessNet.spec
if errorlevel 1 goto :fail

if not exist "%CD%\dist\ChessNet\ChessNet.exe" (
    echo ERROR: PyInstaller finished, but dist\ChessNet\ChessNet.exe was not found.
    goto :fail
)

set "INSTALL_DIR=%LOCALAPPDATA%\ChessNet"
echo.
echo Installing app folder to:
echo   %INSTALL_DIR%

if exist "%INSTALL_DIR%" (
    rmdir /S /Q "%INSTALL_DIR%"
    if errorlevel 1 (
        echo ERROR: Could not remove old install folder.
        echo Close ChessNet if it is running, then try again.
        goto :fail
    )
)

xcopy /E /I /Y "%CD%\dist\ChessNet" "%INSTALL_DIR%" >nul
if errorlevel 1 (
    echo ERROR: Could not copy app folder to LocalAppData.
    goto :fail
)

echo Creating Desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$desktop=[Environment]::GetFolderPath('Desktop');" ^
  "$target=Join-Path $env:LOCALAPPDATA 'ChessNet\ChessNet.exe';" ^
  "$lnk=Join-Path $desktop 'ChessNet.lnk';" ^
  "$shell=New-Object -ComObject WScript.Shell;" ^
  "$shortcut=$shell.CreateShortcut($lnk);" ^
  "$shortcut.TargetPath=$target;" ^
  "$shortcut.WorkingDirectory=Split-Path $target;" ^
  "$shortcut.IconLocation=$target;" ^
  "$shortcut.Description='ChessNet';" ^
  "$shortcut.Save();"
if errorlevel 1 (
    echo ERROR: Could not create Desktop shortcut.
    goto :fail
)

echo.
echo ============================================================
echo Build and install complete.
echo.
echo Fast-launch app folder:
echo   %INSTALL_DIR%
echo.
echo Desktop shortcut:
echo   ChessNet.lnk
echo.
echo Backup build output:
echo   %CD%\dist\ChessNet\ChessNet.exe
echo ============================================================
echo.
pause
exit /b 0

:fail
echo.
echo ERROR: Build failed. Review the messages above.
echo.
pause
exit /b 1
