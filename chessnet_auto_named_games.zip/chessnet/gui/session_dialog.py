"""
Session dialog: the first thing the user sees. Picks the play mode,
shared file, host color, and optional per-side chess clock settings.

Output is a SessionChoice dataclass consumed by main.py to wire up
either local-mode or network-mode play.
"""
from __future__ import annotations

import os
import re
from datetime import datetime
from dataclasses import dataclass, field

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QComboBox,
    QLineEdit, QPushButton, QFileDialog, QMessageBox, QDialogButtonBox,
    QCheckBox, QSpinBox,
)

from ..engine import EngineSettings, load_saved_engine_settings
from ..serialize import COLOR_RANDOM, COLOR_HOST_WHITE, COLOR_HOST_BLACK, COLOR_JOINER_CHOOSES
from .engine_options_dialog import StockfishOptionsDialog


MODE_LOCAL = 'local'
MODE_HOST = 'host'
MODE_JOIN = 'join'
MODE_BOT = 'bot'
MODE_SPECTATE = 'spectate'


@dataclass
class SessionChoice:
    """Result of the session dialog. `cancelled=True` means the user
    closed the dialog without committing -- caller should exit."""
    cancelled: bool = True
    mode: str = MODE_LOCAL
    color: str = 'w'              # 'w' or 'b' -- meaningful for host/local
    file_path: str = ''           # only meaningful for host/join
    game_directory: str = ''      # host convenience input; file_path is generated from this
    white_player_name: str = 'White'
    black_player_name: str = 'Black'
    timer_enabled: bool = False   # local/host only; join reads file setting
    white_seconds: int = 600
    black_seconds: int = 600
    increment_seconds: int = 0
    color_mode: str = COLOR_RANDOM
    engine_settings: EngineSettings = field(default_factory=EngineSettings.defaults)


class SessionDialog(QDialog):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("New Chess Game")
        self.setModal(True)
        self.setMinimumWidth(520)
        self._choice = SessionChoice()

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 12)
        root.setSpacing(10)

        header = QLabel("How do you want to play?")
        f = header.font(); f.setPointSize(14); f.setBold(True)
        header.setFont(f)
        root.addWidget(header)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)
        form.setFormAlignment(Qt.AlignLeft)
        form.setHorizontalSpacing(10)
        form.setVerticalSpacing(8)

        # Mode picker
        self.mode_combo = QComboBox()
        self.mode_combo.addItem("Local (two players, one machine)", MODE_LOCAL)
        self.mode_combo.addItem("Create new shared network game", MODE_HOST)
        self.mode_combo.addItem("Join/rejoin shared network game", MODE_JOIN)
        self.mode_combo.addItem("Play against Stockfish",           MODE_BOT)
        self.mode_combo.addItem("Spectate game with Stockfish eval", MODE_SPECTATE)
        self.mode_combo.currentIndexChanged.connect(self._on_mode_changed)
        form.addRow("Mode:", self.mode_combo)

        # Color picker is used directly for local/bot/rejoin. For new hosted
        # games, color is normally assigned by the color-assignment mode below.
        self.color_combo = QComboBox()
        self.color_combo.addItem("White", 'w')
        self.color_combo.addItem("Black", 'b')
        form.addRow("Your/rejoin color:", self.color_combo)

        self.color_mode_combo = QComboBox()
        self.color_mode_combo.addItem("Random", COLOR_RANDOM)
        self.color_mode_combo.addItem("I play White", COLOR_HOST_WHITE)
        self.color_mode_combo.addItem("I play Black", COLOR_HOST_BLACK)
        self.color_mode_combo.addItem("Let joiner choose", COLOR_JOINER_CHOOSES)
        form.addRow("New-game colors:", self.color_mode_combo)

        # Shared path. In Create mode this is a folder; ChessNet generates the
        # JSON filename automatically from player names + current time/date.
        # In Join/Spectate mode it remains an existing JSON file path.
        path_row = QHBoxLayout()
        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText(r"Choose a shared folder for new games")
        self.path_edit.textChanged.connect(self._update_generated_filename)
        self.browse_btn = QPushButton("Browse...")
        self.browse_btn.clicked.connect(self._on_browse)
        path_row.addWidget(self.path_edit, 1)
        path_row.addWidget(self.browse_btn)
        self.path_label = QLabel("Shared folder:")
        form.addRow(self.path_label, path_row)

        self.white_name_label = QLabel("White player:")
        self.white_name_edit = QLineEdit("White")
        self.white_name_edit.setPlaceholderText("White player name")
        self.white_name_edit.textChanged.connect(self._update_generated_filename)
        form.addRow(self.white_name_label, self.white_name_edit)

        self.black_name_label = QLabel("Black player:")
        self.black_name_edit = QLineEdit("Black")
        self.black_name_edit.setPlaceholderText("Black player name")
        self.black_name_edit.textChanged.connect(self._update_generated_filename)
        form.addRow(self.black_name_label, self.black_name_edit)

        self.generated_file_title_label = QLabel("Generated file:")
        self.generated_file_label = QLabel()
        self.generated_file_label.setWordWrap(True)
        self.generated_file_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.generated_file_label.setStyleSheet("color: #555; font-family: Consolas, monospace; font-size: 10px;")
        form.addRow(self.generated_file_title_label, self.generated_file_label)

        # Stockfish executable path + detailed options. The compact path row
        # keeps startup fast; the Options dialog exposes ELO/depth/hash/etc.
        self.engine_settings = load_saved_engine_settings()
        engine_row = QHBoxLayout()
        self.engine_path_edit = QLineEdit(self.engine_settings.engine_path)
        self.engine_path_edit.setPlaceholderText("Path to stockfish executable")
        self.engine_browse_btn = QPushButton("Browse...")
        self.engine_browse_btn.clicked.connect(self._on_browse_engine)
        self.engine_options_btn = QPushButton("Options...")
        self.engine_options_btn.clicked.connect(self._on_engine_options)
        engine_row.addWidget(self.engine_path_edit, 1)
        engine_row.addWidget(self.engine_browse_btn)
        engine_row.addWidget(self.engine_options_btn)
        form.addRow("Stockfish:", engine_row)

        # Timer controls. Seconds are used instead of minutes so uneven
        # games like White=30 seconds, Black=2 minutes are directly expressible.
        self.timer_check = QCheckBox("Enable chess clock")
        self.timer_check.toggled.connect(self._on_timer_toggled)
        form.addRow("Clock:", self.timer_check)

        self.white_sec_spin = QSpinBox()
        self.white_sec_spin.setRange(1, 24 * 60 * 60)
        self.white_sec_spin.setSingleStep(30)
        self.white_sec_spin.setValue(600)
        self.white_sec_spin.setSuffix(" sec")
        form.addRow("White time:", self.white_sec_spin)

        self.black_sec_spin = QSpinBox()
        self.black_sec_spin.setRange(1, 24 * 60 * 60)
        self.black_sec_spin.setSingleStep(30)
        self.black_sec_spin.setValue(600)
        self.black_sec_spin.setSuffix(" sec")
        form.addRow("Black time:", self.black_sec_spin)

        self.increment_check = QCheckBox("FIDE-style increment after each move")
        self.increment_check.setToolTip("Adds the increment to the player who just completed a legal move.")
        self.increment_check.toggled.connect(lambda _checked: self._on_timer_toggled(self.timer_check.isChecked()))
        form.addRow("Increment mode:", self.increment_check)

        self.increment_sec_spin = QSpinBox()
        self.increment_sec_spin.setRange(0, 60 * 60)
        self.increment_sec_spin.setSingleStep(1)
        self.increment_sec_spin.setValue(30)
        self.increment_sec_spin.setSuffix(" sec/move")
        form.addRow("Increment:", self.increment_sec_spin)

        root.addLayout(form)

        # Help text -- updates with the mode
        self.help_label = QLabel()
        self.help_label.setWordWrap(True)
        self.help_label.setStyleSheet("color: #555; font-size: 11px; padding: 4px;")
        root.addWidget(self.help_label)

        # OK / Cancel
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Start")
        buttons.accepted.connect(self._on_accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

        # Apply initial mode-dependent enables.
        self._on_mode_changed(0)
        self._on_timer_toggled(False)

    # --- public ------------------------------------------------------------

    def choice(self) -> SessionChoice:
        return self._choice

    # --- handlers ----------------------------------------------------------

    def _on_mode_changed(self, _idx: int) -> None:
        mode = self.mode_combo.currentData()
        timer_allowed = mode in (MODE_LOCAL, MODE_HOST, MODE_BOT)
        file_allowed = mode in (MODE_HOST, MODE_JOIN, MODE_SPECTATE)
        engine_allowed = mode in (MODE_BOT, MODE_SPECTATE)
        color_mode_allowed = mode == MODE_HOST
        host_name_allowed = mode == MODE_HOST

        self.color_mode_combo.setEnabled(color_mode_allowed)
        self.white_name_edit.setEnabled(host_name_allowed)
        self.black_name_edit.setEnabled(host_name_allowed)
        self.white_name_edit.setVisible(host_name_allowed)
        self.black_name_edit.setVisible(host_name_allowed)
        self.white_name_label.setVisible(host_name_allowed)
        self.black_name_label.setVisible(host_name_allowed)
        self.generated_file_label.setVisible(host_name_allowed)
        self.generated_file_title_label.setVisible(host_name_allowed)
        self.path_label.setText("Shared folder:" if mode == MODE_HOST else "Shared game file:")
        self.path_edit.setPlaceholderText(
            r"Choose a shared folder; filename is generated automatically"
            if mode == MODE_HOST else
            r"e.g. \\share\chess\game.json"
        )
        self.path_edit.setEnabled(file_allowed)
        self.browse_btn.setEnabled(file_allowed)
        self.engine_path_edit.setEnabled(engine_allowed)
        self.engine_browse_btn.setEnabled(engine_allowed)
        self.engine_options_btn.setEnabled(engine_allowed)

        if mode == MODE_LOCAL:
            self.color_combo.setEnabled(False)
            self.help_label.setText(
                "Two players share one screen. White moves first. "
                "If the chess clock is enabled, each side may have a different time."
            )
        elif mode == MODE_HOST:
            self.color_combo.setEnabled(False)
            self.help_label.setText(
                "Creates a waiting-room game file. Choose the timer and color-assignment mode; "
                "when the second player joins, colors are written into the file and both clients open the game."
            )
        elif mode == MODE_JOIN:
            self.color_combo.setEnabled(True)
            self.help_label.setText(
                "Opens a waiting, active, or completed shared file. Waiting games assign colors automatically; "
                "active games use your saved local player ID when possible, with this color as fallback."
            )
        elif mode == MODE_BOT:
            self.color_combo.setEnabled(True)
            self.help_label.setText(
                "Play locally against Stockfish. Choose your color, optional clock "
                "settings, the Stockfish executable, and engine strength/search options."
            )
        else:  # MODE_SPECTATE
            self.color_combo.setEnabled(False)
            self.help_label.setText(
                "Open an existing shared game read-only. The board stays locked and "
                "Stockfish evaluates every refreshed position with the advantage bar."
            )
        self.timer_check.setEnabled(timer_allowed)
        if not timer_allowed:
            self.timer_check.setChecked(False)
        self._update_generated_filename()
        self._on_timer_toggled(self.timer_check.isChecked() and timer_allowed)

    def _on_timer_toggled(self, checked: bool) -> None:
        enabled = checked and self.timer_check.isEnabled()
        self.white_sec_spin.setEnabled(enabled)
        self.black_sec_spin.setEnabled(enabled)
        self.increment_check.setEnabled(enabled)
        self.increment_sec_spin.setEnabled(enabled and self.increment_check.isChecked())

    def _on_browse(self) -> None:
        mode = self.mode_combo.currentData()
        if mode == MODE_HOST:
            path = QFileDialog.getExistingDirectory(
                self, "Choose shared game folder", self.path_edit.text() or ""
            )
        else:
            path, _ = QFileDialog.getOpenFileName(
                self, "Open existing game file",
                self.path_edit.text() or "",
                "JSON files (*.json);;All files (*)",
            )
        if path:
            self.path_edit.setText(path)
            self._update_generated_filename()


    @staticmethod
    def _safe_name_component(name: str, fallback: str) -> str:
        text = (name or fallback).strip() or fallback
        text = re.sub(r"\s+", "_", text)
        text = re.sub(r"[^A-Za-z0-9_.-]+", "", text)
        text = text.strip("._-") or fallback
        return text

    @classmethod
    def generated_game_filename(cls, white_name: str, black_name: str, when: datetime | None = None) -> str:
        """Return a filename like Levy_vs._Magnus_7_58_052326.json."""
        when = when or datetime.now()
        white = cls._safe_name_component(white_name, "White")
        black = cls._safe_name_component(black_name, "Black")
        hour = when.hour % 12 or 12
        minute = f"{when.minute:02d}"
        date = when.strftime("%m%d%y")
        return f"{white}_vs._{black}_{hour}_{minute}_{date}.json"

    def _generated_game_path(self) -> str:
        directory = self.path_edit.text().strip()
        if not directory:
            return ""
        return os.path.join(
            directory,
            self.generated_game_filename(self.white_name_edit.text(), self.black_name_edit.text()),
        )

    def _update_generated_filename(self) -> None:
        if self.mode_combo.currentData() != MODE_HOST:
            self.generated_file_label.setText("")
            return
        path = self._generated_game_path()
        if path:
            self.generated_file_label.setText(path)
        else:
            self.generated_file_label.setText("Choose a shared folder to generate the game file name.")


    def _on_browse_engine(self) -> None:
        filt = ("Stockfish executable (stockfish*.exe *.exe);;All files (*)"
                if os.name == 'nt' else
                "Stockfish executable (stockfish* *);;All files (*)")
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Stockfish executable", self.engine_path_edit.text() or "", filt
        )
        if path:
            self.engine_path_edit.setText(path)
            self.engine_settings.engine_path = path

    def _on_engine_options(self) -> None:
        self.engine_settings.engine_path = self.engine_path_edit.text().strip()
        dlg = StockfishOptionsDialog(self.engine_settings, require_path=True, parent=self)
        if dlg.exec() == QDialog.Accepted:
            self.engine_settings = dlg.settings()
            self.engine_path_edit.setText(self.engine_settings.engine_path)

    def _on_accept(self) -> None:
        mode = self.mode_combo.currentData()
        color = self.color_combo.currentData()
        raw_path = self.path_edit.text().strip()
        path = raw_path
        game_directory = raw_path if mode == MODE_HOST else ''

        if mode in (MODE_HOST, MODE_JOIN, MODE_SPECTATE):
            if not raw_path:
                QMessageBox.warning(
                    self, "Missing path",
                    "Please provide a shared folder." if mode == MODE_HOST else "Please provide a shared game file path."
                )
                return
            if mode == MODE_HOST:
                if not os.path.isdir(raw_path):
                    QMessageBox.warning(
                        self, "Folder not found",
                        f"The folder does not exist:\n{raw_path}"
                    )
                    return
                path = self._generated_game_path()
            elif not os.path.exists(path):
                QMessageBox.warning(
                    self, "File not found",
                    f"The file does not exist:\n{path}\n\n"
                    "Ask the host to create it first."
                )
                return

        if mode in (MODE_BOT, MODE_SPECTATE):
            self.engine_settings.engine_path = self.engine_path_edit.text().strip()
            if not self.engine_settings.engine_path:
                QMessageBox.warning(self, "Missing Stockfish path", "Please choose a Stockfish executable.")
                return
            if not os.path.exists(self.engine_settings.engine_path):
                QMessageBox.warning(
                    self, "Stockfish not found",
                    f"The executable does not exist:\n{self.engine_settings.engine_path}"
                )
                return

        timer_enabled = bool(self.timer_check.isChecked()) if mode in (MODE_LOCAL, MODE_HOST, MODE_BOT) else False
        self._choice = SessionChoice(
            cancelled=False,
            mode=mode,
            color=color,
            file_path=path,
            game_directory=game_directory,
            white_player_name=self.white_name_edit.text().strip() or 'White',
            black_player_name=self.black_name_edit.text().strip() or 'Black',
            timer_enabled=timer_enabled,
            white_seconds=int(self.white_sec_spin.value()),
            black_seconds=int(self.black_sec_spin.value()),
            increment_seconds=(int(self.increment_sec_spin.value()) if timer_enabled and self.increment_check.isChecked() else 0),
            color_mode=self.color_mode_combo.currentData(),
            engine_settings=self.engine_settings.normalized(),
        )
        self.accept()


class WaitingForPlayerDialog(QDialog):
    """Modal waiting room for a newly hosted shared-file game."""

    def __init__(self, file_path: str, game_id: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Waiting for Opponent")
        self.setModal(True)
        self.setMinimumWidth(520)
        self.file_path = file_path
        self.game_id = game_id
        self.snapshot = None

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 12)
        root.setSpacing(10)

        title = QLabel("Waiting for opponent to join...")
        f = title.font(); f.setPointSize(14); f.setBold(True)
        title.setFont(f)
        root.addWidget(title)

        msg = QLabel(
            "Share this JSON game file with the other player. Once they join, "
            "ChessNet will assign colors and open the board automatically."
        )
        msg.setWordWrap(True)
        root.addWidget(msg)

        path = QLabel(file_path)
        path.setTextInteractionFlags(Qt.TextSelectableByMouse)
        path.setStyleSheet("font-family: Consolas, monospace; color: #333;")
        root.addWidget(path)

        self.status_label = QLabel("Waiting...")
        self.status_label.setStyleSheet("color: #555;")
        root.addWidget(self.status_label)

        buttons = QDialogButtonBox(QDialogButtonBox.Cancel)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

        self.timer = QTimer(self)
        self.timer.setInterval(600)
        self.timer.timeout.connect(self._poll)
        self.timer.start()
        self._poll()

    def _poll(self) -> None:
        try:
            from ..serialize import GameSnapshot
            with open(self.file_path, 'r', encoding='utf-8') as f:
                snap = GameSnapshot.from_json(f.read())
        except Exception as e:
            self.status_label.setText(f"Waiting; could not read file yet: {e}")
            return
        if snap.game_id != self.game_id:
            self.status_label.setText("The shared file was replaced by a different game.")
            return
        if snap.status == 'active':
            self.snapshot = snap
            self.timer.stop()
            self.accept()
        elif snap.status == 'waiting_for_player':
            self.status_label.setText("Still waiting for opponent...")
        else:
            self.status_label.setText(f"Game status changed to {snap.status}.")


@dataclass
class NewGameOptions:
    """Options for restarting the current session without asking for a file."""
    cancelled: bool = True
    color: str = 'w'
    timer_enabled: bool = False
    white_seconds: int = 600
    black_seconds: int = 600
    increment_seconds: int = 0
    color_mode: str = COLOR_RANDOM
    engine_settings: EngineSettings = field(default_factory=EngineSettings.defaults)


class NewGameOptionsDialog(QDialog):
    """Small restart dialog used from an existing game window.

    Network mode reuses the current shared-file path; local mode reuses the
    current window. The user only chooses color/orientation and clock settings.
    """

    def __init__(self, *, network: bool, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Start New Game")
        self.setModal(True)
        self.setMinimumWidth(420)
        self._options = NewGameOptions()
        self._network = bool(network)

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 12)
        root.setSpacing(10)

        header = QLabel("Start a new game")
        f = header.font(); f.setPointSize(14); f.setBold(True)
        header.setFont(f)
        root.addWidget(header)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)
        form.setHorizontalSpacing(10)
        form.setVerticalSpacing(8)

        self.color_combo = QComboBox()
        self.color_combo.addItem("White", 'w')
        self.color_combo.addItem("Black", 'b')
        label = "Your color:" if self._network else "Board starts from:"
        form.addRow(label, self.color_combo)

        self.timer_check = QCheckBox("Enable chess clock")
        self.timer_check.toggled.connect(self._on_timer_toggled)
        form.addRow("Clock:", self.timer_check)

        self.white_sec_spin = QSpinBox()
        self.white_sec_spin.setRange(1, 24 * 60 * 60)
        self.white_sec_spin.setSingleStep(30)
        self.white_sec_spin.setValue(600)
        self.white_sec_spin.setSuffix(" sec")
        form.addRow("White time:", self.white_sec_spin)

        self.black_sec_spin = QSpinBox()
        self.black_sec_spin.setRange(1, 24 * 60 * 60)
        self.black_sec_spin.setSingleStep(30)
        self.black_sec_spin.setValue(600)
        self.black_sec_spin.setSuffix(" sec")
        form.addRow("Black time:", self.black_sec_spin)

        self.increment_check = QCheckBox("FIDE-style increment after each move")
        self.increment_check.setToolTip("Adds the increment to the player who just completed a legal move.")
        self.increment_check.toggled.connect(lambda _checked: self._on_timer_toggled(self.timer_check.isChecked()))
        form.addRow("Increment mode:", self.increment_check)

        self.increment_sec_spin = QSpinBox()
        self.increment_sec_spin.setRange(0, 60 * 60)
        self.increment_sec_spin.setSingleStep(1)
        self.increment_sec_spin.setValue(30)
        self.increment_sec_spin.setSuffix(" sec/move")
        form.addRow("Increment:", self.increment_sec_spin)

        root.addLayout(form)

        help_label = QLabel(
            "The current shared game file will be reused; the other player will "
            "automatically load the new game." if self._network else
            "The current window will be reset; no file path is needed."
        )
        help_label.setWordWrap(True)
        help_label.setStyleSheet("color: #555; font-size: 11px; padding: 4px;")
        root.addWidget(help_label)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Start")
        buttons.accepted.connect(self._on_accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

        self._on_timer_toggled(False)

    def options(self) -> NewGameOptions:
        return self._options

    def _on_timer_toggled(self, checked: bool) -> None:
        enabled = bool(checked)
        self.white_sec_spin.setEnabled(enabled)
        self.black_sec_spin.setEnabled(enabled)
        self.increment_check.setEnabled(enabled)
        self.increment_sec_spin.setEnabled(enabled and self.increment_check.isChecked())

    def _on_accept(self) -> None:
        self._options = NewGameOptions(
            cancelled=False,
            color=self.color_combo.currentData(),
            timer_enabled=bool(self.timer_check.isChecked()),
            white_seconds=int(self.white_sec_spin.value()),
            black_seconds=int(self.black_sec_spin.value()),
            increment_seconds=(int(self.increment_sec_spin.value()) if self.timer_check.isChecked() and self.increment_check.isChecked() else 0),
        )
        self.accept()
