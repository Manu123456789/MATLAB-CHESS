"""Local ChessNet player identity.

This is intentionally a convenience identity, not authentication. It lets a
machine recognize the side it previously played when reopening a shared game.
The ID is created once and stored in the normal per-user AppData/config area.
"""
from __future__ import annotations

import json
import os
import uuid
from dataclasses import dataclass
from pathlib import Path


APP_NAME = "ChessNet"
IDENTITY_FILENAME = "player.json"


def _config_dir() -> Path:
    """Return a per-user config directory.

    On Windows this is usually:
        C:\\Users\\<user>\\AppData\\Roaming\\ChessNet

    On macOS/Linux, this falls back to common user config locations. The app is
    primarily Windows-focused, but this keeps source runs portable.
    """
    appdata = os.environ.get("APPDATA")
    if appdata:
        return Path(appdata) / APP_NAME
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        return Path(xdg) / APP_NAME
    return Path.home() / ".config" / APP_NAME


def identity_path() -> Path:
    return _config_dir() / IDENTITY_FILENAME


@dataclass(frozen=True)
class PlayerIdentity:
    player_id: str
    display_name: str = "Player"

    def to_dict(self) -> dict:
        return {
            "playerId": self.player_id,
            "displayName": self.display_name or "Player",
        }

    @classmethod
    def from_dict(cls, d: dict) -> "PlayerIdentity":
        pid = str(d.get("playerId", "") or "").strip()
        if not pid:
            pid = str(uuid.uuid4())
        name = str(d.get("displayName", "Player") or "Player").strip() or "Player"
        return cls(player_id=pid, display_name=name)


def load_or_create_identity(display_name: str | None = None) -> PlayerIdentity:
    """Load this machine/user's ChessNet identity, creating it if missing."""
    path = identity_path()
    try:
        if path.exists():
            with path.open("r", encoding="utf-8") as f:
                ident = PlayerIdentity.from_dict(json.load(f))
            if display_name and display_name.strip() and ident.display_name == "Player":
                ident = PlayerIdentity(ident.player_id, display_name.strip())
                save_identity(ident)
            return ident
    except (OSError, json.JSONDecodeError, TypeError):
        # If the identity file is corrupt/unreadable, replace it with a fresh
        # identity rather than blocking game startup.
        pass

    ident = PlayerIdentity(str(uuid.uuid4()), (display_name or "Player").strip() or "Player")
    save_identity(ident)
    return ident


def save_identity(identity: PlayerIdentity) -> None:
    path = identity_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(identity.to_dict(), f, indent=2)
    os.replace(tmp, path)
