"""Small opt-in startup profiler for development builds.

Set CHESSNET_PROFILE_STARTUP=1 before launching ChessNet to print elapsed
startup checkpoints to stderr. Disabled by default and safe in packaged builds.
"""
from __future__ import annotations

import os
import sys
import time

_ENABLED = os.environ.get('CHESSNET_PROFILE_STARTUP', '').strip().lower() in {'1', 'true', 'yes', 'on'}
_T0 = time.perf_counter()
_LAST = _T0


def mark(label: str) -> None:
    """Print a startup timing checkpoint when profiling is enabled."""
    global _LAST
    if not _ENABLED:
        return
    now = time.perf_counter()
    print(
        f"[ChessNet startup] {label}: +{now - _LAST:.3f}s / {now - _T0:.3f}s total",
        file=sys.stderr,
        flush=True,
    )
    _LAST = now
