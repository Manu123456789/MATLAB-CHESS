"""Regression tests for the shared-file waiting-room setup flow.

These tests are intentionally model-level so the GUI can change without
changing the network setup contract.
"""
import os
import tempfile

from chessnet.identity import PlayerIdentity
from chessnet.netgame import NetGame
from chessnet.serialize import (
    GameSnapshot,
    COLOR_HOST_BLACK,
    COLOR_HOST_WHITE,
    COLOR_RANDOM,
)


def _write(path, snap):
    ng = NetGame(path, 'w', snap)
    ng.bootstrap(snap)


def test_waiting_snapshot_round_trip_keeps_host_identity():
    host = PlayerIdentity('host-id', 'Host').to_dict()
    snap = GameSnapshot.waiting_for_player(host_identity=host, color_mode=COLOR_RANDOM)
    back = GameSnapshot.from_json(snap.to_json())
    assert back.status == 'waiting_for_player'
    assert back.players['host']['playerId'] == 'host-id'
    assert back.setup['colorMode'] == COLOR_RANDOM


def test_joiner_finalizes_fixed_host_white_game():
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, 'game.json')
        host = PlayerIdentity('host-id', 'Host').to_dict()
        joiner = PlayerIdentity('joiner-id', 'Joiner').to_dict()
        _write(path, GameSnapshot.waiting_for_player(host_identity=host, color_mode=COLOR_HOST_WHITE))

        snap, my_color = NetGame.finalize_waiting_game(path, joiner_identity=joiner)
        assert snap.status == 'active'
        assert snap.host_color == 'w'
        assert my_color == 'b'
        assert snap.players['white']['playerId'] == 'host-id'
        assert snap.players['black']['playerId'] == 'joiner-id'
        assert NetGame.color_for_identity(snap, 'host-id') == 'w'
        assert NetGame.color_for_identity(snap, 'joiner-id') == 'b'


def test_joiner_finalizes_fixed_host_black_game():
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, 'game.json')
        host = PlayerIdentity('host-id', 'Host').to_dict()
        joiner = PlayerIdentity('joiner-id', 'Joiner').to_dict()
        _write(path, GameSnapshot.waiting_for_player(host_identity=host, color_mode=COLOR_HOST_BLACK))

        snap, my_color = NetGame.finalize_waiting_game(path, joiner_identity=joiner)
        assert snap.host_color == 'b'
        assert my_color == 'w'
        assert snap.players['white']['playerId'] == 'joiner-id'
        assert snap.players['black']['playerId'] == 'host-id'


def test_random_waiting_game_always_assigns_complementary_colors_even_same_local_identity():
    """If host/joiner share one AppData identity, do not auto-map both windows to one color."""
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, 'game.json')
        same_id_host = PlayerIdentity('same-machine-id', 'HostWindow').to_dict()
        same_id_joiner = PlayerIdentity('same-machine-id', 'JoinerWindow').to_dict()
        _write(path, GameSnapshot.waiting_for_player(host_identity=same_id_host, color_mode=COLOR_RANDOM))

        snap, joiner_color = NetGame.finalize_waiting_game(path, joiner_identity=same_id_joiner)
        host_color = snap.color_assignment['hostColor']

        assert {host_color, joiner_color} == {'w', 'b'}
        assert snap.players['white']['playerId'] == 'same-machine-id'
        assert snap.players['black']['playerId'] == 'same-machine-id'
        assert NetGame.color_for_identity(snap, 'same-machine-id') is None
