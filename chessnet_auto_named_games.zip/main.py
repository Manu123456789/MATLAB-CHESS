"""ChessNet entry point.

Shows the session dialog, then opens the main window in either local
hot-seat or network mode based on the user's choice.

Usage:
    python main.py
"""
from __future__ import annotations

import os
import sys

from chessnet.startup_profile import mark
mark("stdlib imports complete")

import chess
from PySide6.QtWidgets import QApplication, QMessageBox, QDialog

from chessnet.model import Game
from chessnet.netgame import NetGame, WrongGameError, WaitingGameError
from chessnet.serialize import GameSnapshot, TimerState, COLOR_RANDOM
from chessnet.gui.session_dialog import (
    SessionDialog, WaitingForPlayerDialog, MODE_LOCAL, MODE_HOST, MODE_JOIN, MODE_BOT, MODE_SPECTATE,
)
from chessnet.gui.main_window import MainWindow
from chessnet.identity import load_or_create_identity, identity_path
mark("application imports complete")


def main() -> int:
    mark("creating QApplication")
    app = QApplication(sys.argv)

    mark("showing session dialog")
    dlg = SessionDialog()
    if dlg.exec() != QDialog.Accepted:
        return 0
    mark("session dialog accepted")
    choice = dlg.choice()
    if choice.cancelled:
        return 0

    if choice.mode == MODE_LOCAL:
        timer = TimerState.from_seconds(
            choice.timer_enabled,
            choice.white_seconds,
            choice.black_seconds,
            increment_seconds=choice.increment_seconds,
            local=True,
        )
        win = MainWindow(Game(), orientation=chess.WHITE, timer_state=timer)
    elif choice.mode == MODE_HOST:
        win = _host_window(
            choice.file_path,
            choice.color,
            choice.timer_enabled,
            choice.white_seconds,
            choice.black_seconds,
            choice.increment_seconds,
            choice.color_mode,
            choice.white_player_name,
            choice.black_player_name,
        )
        if win is None:
            return 1
    elif choice.mode == MODE_JOIN:
        win = _join_window(choice.file_path, choice.color)
        if win is None:
            return 1
    elif choice.mode == MODE_BOT:
        timer = TimerState.from_seconds(
            choice.timer_enabled,
            choice.white_seconds,
            choice.black_seconds,
            increment_seconds=choice.increment_seconds,
            local=True,
        )
        human_color = chess.WHITE if choice.color == 'w' else chess.BLACK
        engine_color = not human_color
        win = MainWindow(
            Game(),
            orientation=human_color,
            timer_state=timer,
            bot_color=engine_color,
            engine_settings=choice.engine_settings,
            evaluation_enabled=True,
        )
    elif choice.mode == MODE_SPECTATE:
        win = _spectate_window(choice.file_path, choice.engine_settings)
        if win is None:
            return 1
    else:
        QMessageBox.critical(None, "Unknown mode", f"Mode: {choice.mode}")
        return 1

    mark("main window constructed")
    win.show()
    mark("main window shown")
    return app.exec()


def _host_window(file_path: str,
                 host_color: str,
                 timer_enabled: bool = False,
                 white_seconds: int = 600,
                 black_seconds: int = 600,
                 increment_seconds: int = 0,
                 color_mode: str = COLOR_RANDOM,
                 white_player_name: str = 'White',
                 black_player_name: str = 'Black') -> MainWindow | None:
    """Create a waiting-room game file, then open when the second player joins."""
    file_path = os.path.abspath(file_path)
    if os.path.exists(file_path):
        r = QMessageBox.question(
            None, "File exists",
            f"{file_path}\n\nalready exists. Overwrite with a new waiting-room game?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
        )
        if r != QMessageBox.Yes:
            return None

    identity = load_or_create_identity()
    timer = TimerState.from_seconds(
        timer_enabled,
        white_seconds,
        black_seconds,
        increment_seconds=increment_seconds,
    )
    snap = GameSnapshot.waiting_for_player(
        host_identity=identity.to_dict(),
        color_mode=color_mode,
        timer=timer,
        white_player_name=white_player_name,
        black_player_name=black_player_name,
    )
    # Build the NetGame with a provisional host color. The real color is
    # assigned when the joiner finalizes the waiting-room snapshot.
    netgame = NetGame(file_path, my_color='w', snapshot=snap)
    try:
        netgame.bootstrap(snap)
    except OSError as e:
        QMessageBox.critical(
            None, "Cannot create game file",
            f"Failed to write {file_path}:\n\n{e}"
        )
        return None

    wait = WaitingForPlayerDialog(file_path, snap.game_id)
    if wait.exec() != QDialog.Accepted or wait.snapshot is None:
        return None

    active = wait.snapshot
    my_color = NetGame.color_for_identity(active, identity.player_id)
    if my_color not in ('w', 'b'):
        # Fallback should rarely be needed, but preserve old behavior if the
        # local identity file was deleted while the waiting dialog was open.
        my_color = active.host_color
    netgame = NetGame(file_path, my_color=my_color, snapshot=active)
    orient = chess.WHITE if my_color == 'w' else chess.BLACK
    return MainWindow(active.to_game(), netgame=netgame, orientation=orient)


def _join_window(file_path: str, my_color: str | None = None) -> MainWindow | None:
    """Join a waiting game or rejoin an active/completed shared-file game."""
    file_path = os.path.abspath(file_path)
    identity = load_or_create_identity()
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            snap = GameSnapshot.from_json(f.read())
    except (OSError, ValueError) as e:
        QMessageBox.critical(
            None, "Cannot open game file",
            f"Failed to read {file_path}:\n\n{e}"
        )
        return None

    if snap.status == 'waiting_for_player':
        try:
            snap, my_color = NetGame.finalize_waiting_game(
                file_path,
                joiner_identity=identity.to_dict(),
                preferred_color=my_color,
            )
            QMessageBox.information(
                None,
                "Joined Game",
                f"Joined successfully. You are playing {'White' if my_color == 'w' else 'Black'}."
            )
        except (OSError, WaitingGameError, ValueError) as e:
            QMessageBox.critical(
                None,
                "Cannot join waiting game",
                f"Failed to join {file_path}:\n\n{e}"
            )
            return None
    else:
        recognized = NetGame.color_for_identity(snap, identity.player_id)
        if recognized in ('w', 'b'):
            my_color = recognized
            QMessageBox.information(
                None,
                "Rejoin Game",
                f"Recognized this Windows user/app install as {'White' if my_color == 'w' else 'Black'}."
            )
        elif my_color not in ('w', 'b'):
            # Legacy files may not have player identity fields. Fall back to the
            # old host/opposite rule, while still letting the dialog-provided
            # color override when available.
            my_color = 'b' if snap.host_color == 'w' else 'w'

    netgame = NetGame(file_path, my_color=my_color, snapshot=snap)
    orient = chess.WHITE if my_color == 'w' else chess.BLACK
    return MainWindow(snap.to_game(), netgame=netgame, orientation=orient)


def _spectate_window(file_path: str, engine_settings) -> MainWindow | None:
    """Read an existing game file as a read-only spectator with engine eval."""
    file_path = os.path.abspath(file_path)
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            snap = GameSnapshot.from_json(f.read())
    except (OSError, ValueError) as e:
        QMessageBox.critical(
            None, "Cannot open game file",
            f"Failed to read {file_path}:\n\n{e}"
        )
        return None

    # NetGame still provides robust load/rebind/watch behavior. The window's
    # spectator flag prevents any writes or moves from this client.
    netgame = NetGame(file_path, my_color='w', snapshot=snap)
    return MainWindow(
        snap.to_game(),
        netgame=netgame,
        orientation=chess.WHITE,
        spectator=True,
        engine_settings=engine_settings,
        evaluation_enabled=True,
    )


if __name__ == "__main__":
    sys.exit(main())
