#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

SOURCE_APP="dist/ChessNet.app"
INSTALL_DIR="$HOME/Applications"
INSTALL_APP="$INSTALL_DIR/ChessNet.app"
DESKTOP_ALIAS="$HOME/Desktop/ChessNet"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "[ChessNet Install] This script is for macOS only."
  exit 1
fi

if [ ! -d "$SOURCE_APP" ]; then
  echo "[ChessNet Install] Could not find built app: $SOURCE_APP"
  echo "Run ./build_macos_app.sh first."
  exit 1
fi

echo "[ChessNet Install] Installing to $INSTALL_APP..."
mkdir -p "$INSTALL_DIR"
rm -rf "$INSTALL_APP"
ditto "$SOURCE_APP" "$INSTALL_APP"

echo "[ChessNet Install] Creating Desktop alias..."
rm -f "$DESKTOP_ALIAS" "$DESKTOP_ALIAS.alias"
osascript <<APPLESCRIPT || ln -s "$INSTALL_APP" "$DESKTOP_ALIAS"
tell application "Finder"
    make alias file to POSIX file "$INSTALL_APP" at POSIX file "$HOME/Desktop"
    set name of result to "ChessNet"
end tell
APPLESCRIPT

echo
echo "[ChessNet Install] Done."
echo "Installed app: $INSTALL_APP"
echo "Players can now double-click ChessNet from Applications or the Desktop alias."
