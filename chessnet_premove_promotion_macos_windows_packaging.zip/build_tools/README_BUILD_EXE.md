# Building ChessNet Desktop Apps

The project now uses fast one-folder/app-bundle packaging rather than a single huge executable.

## Windows

Run:

```bat
build_windows_app.bat
install_chessnet_desktop.bat
```

Output:

```text
dist\ChessNet\ChessNet.exe
%LOCALAPPDATA%\ChessNet\ChessNet.exe
Desktop\ChessNet.lnk
```

## macOS

Run on macOS:

```bash
./build_macos_app.sh
./install_chessnet_macos.sh
```

Output:

```text
dist/ChessNet.app
dist/ChessNet-macOS.zip
~/Applications/ChessNet.app
Desktop alias: ChessNet
```

Stockfish is not bundled. Users still point ChessNet to their Stockfish executable from the GUI.
