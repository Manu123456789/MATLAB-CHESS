#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

VENV=".venv"
PYTHON="$VENV/bin/python"

if [ ! -x "$PYTHON" ]; then
  echo "[ChessNet] Creating source-development virtual environment..."
  python3 -m venv "$VENV"
fi

REQ_HASH="$(shasum -a 256 requirements.txt | awk '{print $1}')"
HASH_FILE="$VENV/.requirements_hash"
OLD_HASH=""
if [ -f "$HASH_FILE" ]; then
  OLD_HASH="$(cat "$HASH_FILE")"
fi

if [ "$REQ_HASH" != "$OLD_HASH" ]; then
  echo "[ChessNet] Requirements changed or first source run. Installing dependencies once..."
  "$PYTHON" -m pip install --upgrade pip
  "$PYTHON" -m pip install -r requirements.txt
  printf "%s" "$REQ_HASH" > "$HASH_FILE"
else
  echo "[ChessNet] Requirements unchanged. Skipping dependency install."
fi

echo "[ChessNet] Starting from source..."
exec "$PYTHON" main.py
