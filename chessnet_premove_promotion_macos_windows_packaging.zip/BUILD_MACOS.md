# Building and Installing ChessNet on macOS

This project can build a native macOS app bundle:

```text
dist/ChessNet.app
```

PyInstaller is not a cross-compiler, so this build must be run on macOS.

## 1. Build the app

From Terminal in the project root:

```bash
chmod +x build_macos_app.sh install_chessnet_macos.sh run_chessnet_macos.sh
./build_macos_app.sh
```

This creates:

```text
dist/ChessNet.app
dist/ChessNet-macOS.zip
```

The `.zip` is the file to send to another Mac user.

## 2. Install locally and create a Desktop alias

After the build succeeds:

```bash
./install_chessnet_macos.sh
```

This installs:

```text
~/Applications/ChessNet.app
```

and creates a Desktop alias named:

```text
ChessNet
```

Players can double-click either the app in `~/Applications` or the Desktop alias.

## 3. Gatekeeper note

The build script applies an ad-hoc local code signature when `codesign` is available. This is enough for local testing, but it is not Apple notarization.

For distribution outside your own machine, users may need to right-click the app and choose **Open** the first time, unless you later sign and notarize the app with an Apple Developer ID.

## 4. Apple Silicon vs Intel

The app architecture follows the Python interpreter used to build it.

- Apple Silicon Python builds Apple Silicon apps.
- Intel Python builds Intel apps.
- Universal2 Python is required if you later want to produce one universal app bundle.

## 5. Source-code launcher

For development without packaging:

```bash
./run_chessnet_macos.sh
```
