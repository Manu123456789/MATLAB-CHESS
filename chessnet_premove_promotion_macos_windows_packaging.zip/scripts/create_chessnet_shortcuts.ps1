param(
    [Parameter(Mandatory = $true)]
    [string]$InstallDir
)

$ErrorActionPreference = "Stop"

$installDirResolved = (Resolve-Path -LiteralPath $InstallDir).Path
$exePath = Join-Path $installDirResolved "ChessNet.exe"
if (-not (Test-Path -LiteralPath $exePath)) {
    throw "ChessNet.exe not found at $exePath"
}

$wsh = New-Object -ComObject WScript.Shell

function New-ChessNetShortcut {
    param(
        [Parameter(Mandatory = $true)] [string]$ShortcutPath
    )

    $shortcut = $wsh.CreateShortcut($ShortcutPath)
    $shortcut.TargetPath = $exePath
    $shortcut.WorkingDirectory = $installDirResolved
    $shortcut.IconLocation = $exePath
    $shortcut.Description = "Launch ChessNet"
    $shortcut.Save()
}

$desktop = [Environment]::GetFolderPath("Desktop")
New-ChessNetShortcut -ShortcutPath (Join-Path $desktop "ChessNet.lnk")

$programs = [Environment]::GetFolderPath("Programs")
$startMenuDir = Join-Path $programs "ChessNet"
New-Item -ItemType Directory -Force -Path $startMenuDir | Out-Null
New-ChessNetShortcut -ShortcutPath (Join-Path $startMenuDir "ChessNet.lnk")

Write-Host "Created Desktop shortcut and Start Menu shortcut."
