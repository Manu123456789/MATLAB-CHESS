# Building and Installing ChessNet on Windows

This project is set up to build a fast-starting Windows desktop app using PyInstaller **one-folder** mode.

The final player experience is:

```text
Double-click Desktop\ChessNet.lnk
```

The real executable lives at:

```text
%LOCALAPPDATA%\ChessNet\ChessNet.exe
```

Do not copy only `ChessNet.exe` to the Desktop. The one-folder app also needs its `_internal` folder.

## 1. Build the app

From the project root, double-click or run:

```bat
build_windows_app.bat
```

This creates:

```text
dist\ChessNet\ChessNet.exe
dist\ChessNet\_internal\...
dist\ChessNet\assets\...
```

## 2. Install locally and create shortcuts

After the build succeeds, run:

```bat
install_chessnet_desktop.bat
```

This copies the built app to:

```text
%LOCALAPPDATA%\ChessNet\
```

and creates:

```text
Desktop\ChessNet.lnk
Start Menu\ChessNet\ChessNet.lnk
```

## 3. Development launcher

For source development, use:

```bat
run_chessnet.bat
```

This launcher creates `.venv` only if needed and installs requirements only when `requirements.txt` changes.

## 4. Stockfish

Stockfish is not bundled. Users can point ChessNet to their own Stockfish executable from the app's Stockfish options.
