# ChessNet Desktop Builds

ChessNet now has build paths for both Windows and macOS.

## Windows

```bat
build_windows_app.bat
install_chessnet_desktop.bat
```

Result:

```text
%LOCALAPPDATA%\ChessNet\ChessNet.exe
Desktop\ChessNet.lnk
```

See `BUILD_WINDOWS.md`.

## macOS

```bash
./build_macos_app.sh
./install_chessnet_macos.sh
```

Result:

```text
~/Applications/ChessNet.app
~/Desktop/ChessNet alias
dist/ChessNet-macOS.zip
```

See `BUILD_MACOS.md`.

## Why builds happen on each target OS

PyInstaller packages the Python interpreter, native extension modules, Qt libraries, and platform-specific bootloader for the operating system it is running on. Therefore, build Windows on Windows and macOS on macOS.
