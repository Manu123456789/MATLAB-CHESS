#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "[ChessNet Build] This script must be run on macOS to create ChessNet.app."
  echo "[ChessNet Build] PyInstaller is not a cross-compiler. Build Windows on Windows and macOS on macOS."
  exit 1
fi

BUILD_VENV=".venv-build"
PYTHON="$BUILD_VENV/bin/python"

if [ ! -x "$PYTHON" ]; then
  echo "[ChessNet Build] Creating clean build virtual environment..."
  python3 -m venv "$BUILD_VENV"
fi

echo "[ChessNet Build] Installing build dependencies..."
"$PYTHON" -m pip install --upgrade pip
"$PYTHON" -m pip install -r requirements.txt
"$PYTHON" -m pip install -r requirements-build.txt

echo "[ChessNet Build] Removing old build output..."
rm -rf build dist

echo "[ChessNet Build] Building macOS app bundle with PyInstaller..."
"$PYTHON" -m PyInstaller --noconfirm --clean ChessNet.spec

if [ ! -d "dist/ChessNet.app" ]; then
  echo "[ChessNet Build] Build finished but dist/ChessNet.app was not found."
  exit 1
fi

if command -v codesign >/dev/null 2>&1; then
  echo "[ChessNet Build] Applying ad-hoc local code signature..."
  codesign --force --deep --sign - "dist/ChessNet.app" || true
fi

echo "[ChessNet Build] Creating distributable zip..."
rm -f "dist/ChessNet-macOS.zip"
ditto -c -k --sequesterRsrc --keepParent "dist/ChessNet.app" "dist/ChessNet-macOS.zip"

echo
echo "[ChessNet Build] Done."
echo "App:  $(pwd)/dist/ChessNet.app"
echo "Zip:  $(pwd)/dist/ChessNet-macOS.zip"
echo
echo "Next step: run ./install_chessnet_macos.sh to install the app for double-click launching."
