"""ChessNet entry point.

Shows the session dialog first, then lazy-loads the heavier game window,
network, watcher, and engine-facing modules only after the user chooses a mode.

Usage:
    python main.py
"""
from __future__ import annotations

import os
import sys
import time

from PySide6.QtWidgets import QApplication, QMessageBox, QDialog

from chessnet.gui.session_dialog import (
    SessionDialog, MODE_LOCAL, MODE_HOST, MODE_JOIN, MODE_BOT, MODE_SPECTATE,
)

_PROFILE_STARTUP = os.environ.get("CHESSNET_PROFILE_STARTUP", "").strip().lower() in {
    "1", "true", "yes", "on",
}
_START_TIME = time.perf_counter()


def _startup_mark(label: str) -> None:
    """Print lightweight startup timing only when explicitly requested."""
    if _PROFILE_STARTUP:
        elapsed = time.perf_counter() - _START_TIME
        print(f"[ChessNet startup] {elapsed:0.3f}s  {label}", flush=True)


def main() -> int:
    _startup_mark("imports complete")
    app = QApplication(sys.argv)
    _startup_mark("QApplication created")

    dlg = SessionDialog()
    _startup_mark("session dialog created")
    if dlg.exec() != QDialog.Accepted:
        return 0
    choice = dlg.choice()
    if choice.cancelled:
        return 0
    _startup_mark(f"mode selected: {choice.mode}")

    if choice.mode == MODE_LOCAL:
        win = _local_window(choice)
    elif choice.mode == MODE_HOST:
        win = _host_window(
            choice.file_path,
            choice.color,
            choice.timer_enabled,
            choice.white_seconds,
            choice.black_seconds,
            choice.increment_seconds,
        )
        if win is None:
            return 1
    elif choice.mode == MODE_JOIN:
        win = _join_window(choice.file_path, choice.color)
        if win is None:
            return 1
    elif choice.mode == MODE_BOT:
        win = _bot_window(choice)
    elif choice.mode == MODE_SPECTATE:
        win = _spectate_window(choice.file_path, choice.engine_settings)
        if win is None:
            return 1
    else:
        QMessageBox.critical(None, "Unknown mode", f"Mode: {choice.mode}")
        return 1

    _startup_mark("main window constructed")
    win.show()
    _startup_mark("main window shown")
    return app.exec()


def _local_window(choice):
    import chess
    from chessnet.model import Game
    from chessnet.serialize import TimerState
    from chessnet.gui.main_window import MainWindow

    timer = TimerState.from_seconds(
        choice.timer_enabled,
        choice.white_seconds,
        choice.black_seconds,
        increment_seconds=choice.increment_seconds,
        local=True,
    )
    return MainWindow(Game(), orientation=chess.WHITE, timer_state=timer)


def _bot_window(choice):
    import chess
    from chessnet.model import Game
    from chessnet.serialize import TimerState
    from chessnet.gui.main_window import MainWindow

    timer = TimerState.from_seconds(
        choice.timer_enabled,
        choice.white_seconds,
        choice.black_seconds,
        increment_seconds=choice.increment_seconds,
        local=True,
    )
    human_color = chess.WHITE if choice.color == 'w' else chess.BLACK
    engine_color = not human_color
    return MainWindow(
        Game(),
        orientation=human_color,
        timer_state=timer,
        bot_color=engine_color,
        engine_settings=choice.engine_settings,
        evaluation_enabled=True,
    )


def _host_window(file_path: str, host_color: str, timer_enabled: bool = False, white_seconds: int = 600, black_seconds: int = 600, increment_seconds: int = 0):
    """Create a fresh game, write it to `file_path`, return the main window."""
    import chess
    from chessnet.netgame import NetGame
    from chessnet.serialize import GameSnapshot, TimerState
    from chessnet.gui.main_window import MainWindow

    file_path = os.path.abspath(file_path)
    if os.path.exists(file_path):
        r = QMessageBox.question(
            None, "File exists",
            f"{file_path}\n\nalready exists. Overwrite with a new game?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
        )
        if r != QMessageBox.Yes:
            return None

    timer = TimerState.from_seconds(
        timer_enabled,
        white_seconds,
        black_seconds,
        increment_seconds=increment_seconds,
        opened_color=host_color,
    )
    snap = GameSnapshot.initial(host_color, timer=timer)
    # Build the NetGame with a placeholder snapshot, then bootstrap to
    # write the real one. bootstrap() updates last_seen and game_id.
    netgame = NetGame(file_path, my_color=host_color, snapshot=snap)
    try:
        netgame.bootstrap(snap)
    except OSError as e:
        QMessageBox.critical(
            None, "Cannot create game file",
            f"Failed to write {file_path}:\n\n{e}"
        )
        return None

    orient = chess.WHITE if host_color == 'w' else chess.BLACK
    return MainWindow(snap.to_game(), netgame=netgame, orientation=orient)


def _join_window(file_path: str, my_color: str | None = None):
    """Read an existing game file and join as the selected color."""
    import chess
    from chessnet.netgame import NetGame
    from chessnet.serialize import GameSnapshot
    from chessnet.gui.main_window import MainWindow

    file_path = os.path.abspath(file_path)
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            snap = GameSnapshot.from_json(f.read())
    except (OSError, ValueError) as e:
        QMessageBox.critical(
            None, "Cannot open game file",
            f"Failed to read {file_path}:\n\n{e}"
        )
        return None

    if my_color not in ('w', 'b'):
        my_color = 'b' if snap.host_color == 'w' else 'w'
    netgame = NetGame(file_path, my_color=my_color, snapshot=snap)
    orient = chess.WHITE if my_color == 'w' else chess.BLACK
    return MainWindow(snap.to_game(), netgame=netgame, orientation=orient)


def _spectate_window(file_path: str, engine_settings):
    """Read an existing game file as a read-only spectator with engine eval."""
    import chess
    from chessnet.netgame import NetGame
    from chessnet.serialize import GameSnapshot
    from chessnet.gui.main_window import MainWindow

    file_path = os.path.abspath(file_path)
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            snap = GameSnapshot.from_json(f.read())
    except (OSError, ValueError) as e:
        QMessageBox.critical(
            None, "Cannot open game file",
            f"Failed to read {file_path}:\n\n{e}"
        )
        return None

    # NetGame still provides robust load/rebind/watch behavior. The window's
    # spectator flag prevents any writes or moves from this client.
    netgame = NetGame(file_path, my_color='w', snapshot=snap)
    return MainWindow(
        snap.to_game(),
        netgame=netgame,
        orientation=chess.WHITE,
        spectator=True,
        engine_settings=engine_settings,
        evaluation_enabled=True,
    )


if __name__ == "__main__":
    sys.exit(main())
