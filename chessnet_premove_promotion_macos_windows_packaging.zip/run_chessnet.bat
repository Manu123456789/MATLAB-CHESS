@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "VENV=.venv"
set "PYTHON=%VENV%\Scripts\python.exe"

if not exist "%PYTHON%" (
    echo [ChessNet] Creating source-development virtual environment...
    py -3 -m venv "%VENV%" 2>nul || python -m venv "%VENV%"
    if errorlevel 1 (
        echo [ChessNet] Failed to create virtual environment. Install Python 3 and make sure py/python is on PATH.
        pause
        exit /b 1
    )
)

for /f "usebackq delims=" %%H in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "(Get-FileHash -Algorithm SHA256 'requirements.txt').Hash"`) do set "REQ_HASH=%%H"
set "HASH_FILE=%VENV%\.requirements_hash"
set "OLD_HASH="
if exist "%HASH_FILE%" set /p OLD_HASH=<"%HASH_FILE%"

if /I not "%REQ_HASH%"=="%OLD_HASH%" (
    echo [ChessNet] Requirements changed or first source run. Installing dependencies once...
    "%PYTHON%" -m pip install --upgrade pip
    if errorlevel 1 goto :pip_fail
    "%PYTHON%" -m pip install -r requirements.txt
    if errorlevel 1 goto :pip_fail
    >"%HASH_FILE%" echo %REQ_HASH%
) else (
    echo [ChessNet] Requirements unchanged. Skipping dependency install.
)

echo [ChessNet] Starting from source...
"%PYTHON%" main.py
exit /b %ERRORLEVEL%

:pip_fail
echo [ChessNet] Dependency installation failed.
pause
exit /b 1
