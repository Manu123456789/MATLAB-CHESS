# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec for ChessNet desktop builds.

Windows output:
    dist/ChessNet/ChessNet.exe

macOS output when built on macOS:
    dist/ChessNet.app

This intentionally uses one-folder / app-bundle style packaging instead of
one-file packaging so PySide6 starts faster and does not repeatedly unpack a
large runtime at launch.
"""
from pathlib import Path
import sys

from PyInstaller.utils.hooks import collect_submodules

project_dir = Path(SPECPATH)
sys.path.insert(0, str(project_dir))

assets_dir = project_dir / "assets"
readme_path = project_dir / "README.md"
windows_icon = assets_dir / "chessnet.ico"
macos_icon = assets_dir / "chessnet.icns"

datas = []
if assets_dir.exists():
    datas.append((str(assets_dir), "assets"))
if readme_path.exists():
    datas.append((str(readme_path), "."))

# Be explicit about dynamic/lazy app modules. PyInstaller's PySide6 hooks
# collect Qt plugins/binaries; this covers ChessNet modules imported after
# startup mode selection.
hiddenimports = []
hiddenimports += collect_submodules("chessnet")
hiddenimports += collect_submodules("chess")
hiddenimports += collect_submodules("watchdog")

a = Analysis(
    ["main.py"],
    pathex=[str(project_dir)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="ChessNet",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=str(windows_icon) if sys.platform.startswith("win") and windows_icon.exists() else None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="ChessNet",
    contents_directory="_internal",
)

if sys.platform == "darwin":
    app = BUNDLE(
        coll,
        name="ChessNet.app",
        icon=str(macos_icon) if macos_icon.exists() else None,
        bundle_identifier="com.chessnet.app",
        info_plist={
            "CFBundleName": "ChessNet",
            "CFBundleDisplayName": "ChessNet",
            "CFBundleShortVersionString": "1.0.0",
            "CFBundleVersion": "1.0.0",
            "NSHighResolutionCapable": "True",
            "NSHumanReadableCopyright": "ChessNet",
        },
    )
