@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "BUILD_VENV=.venv-build"
set "PYTHON=%BUILD_VENV%\Scripts\python.exe"

if not exist "%PYTHON%" (
    echo [ChessNet Build] Creating clean build virtual environment...
    py -3 -m venv "%BUILD_VENV%" 2>nul || python -m venv "%BUILD_VENV%"
    if errorlevel 1 (
        echo [ChessNet Build] Failed to create build virtual environment. Install Python 3 and make sure py/python is on PATH.
        pause
        exit /b 1
    )
)

echo [ChessNet Build] Installing build dependencies...
"%PYTHON%" -m pip install --upgrade pip
if errorlevel 1 goto :fail
"%PYTHON%" -m pip install -r requirements.txt
if errorlevel 1 goto :fail
"%PYTHON%" -m pip install -r requirements-build.txt
if errorlevel 1 goto :fail

echo [ChessNet Build] Removing old build output...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

echo [ChessNet Build] Building one-folder Windows app with PyInstaller...
"%PYTHON%" -m PyInstaller --noconfirm --clean ChessNet.spec
if errorlevel 1 goto :fail

if not exist "dist\ChessNet\ChessNet.exe" (
    echo [ChessNet Build] Build finished but dist\ChessNet\ChessNet.exe was not found.
    pause
    exit /b 1
)

echo.
echo [ChessNet Build] Done.
echo Output: %CD%\dist\ChessNet\ChessNet.exe
echo.
echo Next step: run install_chessnet_desktop.bat to copy the app to %%LOCALAPPDATA%%\ChessNet and create shortcuts.
exit /b 0

:fail
echo [ChessNet Build] Build failed.
pause
exit /b 1
