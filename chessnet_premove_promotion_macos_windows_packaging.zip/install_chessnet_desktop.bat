@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "SOURCE_DIR=%CD%\dist\ChessNet"
set "SOURCE_EXE=%SOURCE_DIR%\ChessNet.exe"
set "INSTALL_DIR=%LOCALAPPDATA%\ChessNet"

if not exist "%SOURCE_EXE%" (
    echo [ChessNet Install] Could not find built app:
    echo "%SOURCE_EXE%"
    echo.
    echo Run build_windows_app.bat first.
    pause
    exit /b 1
)

echo [ChessNet Install] Installing to "%INSTALL_DIR%"...
if exist "%INSTALL_DIR%" rmdir /s /q "%INSTALL_DIR%"
mkdir "%INSTALL_DIR%"
if errorlevel 1 goto :fail

robocopy "%SOURCE_DIR%" "%INSTALL_DIR%" /MIR /NFL /NDL /NJH /NJS /NP
if errorlevel 8 goto :fail

echo [ChessNet Install] Creating Desktop and Start Menu shortcuts...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\create_chessnet_shortcuts.ps1" -InstallDir "%INSTALL_DIR%"
if errorlevel 1 goto :fail

echo.
echo [ChessNet Install] Done.
echo Desktop shortcut: ChessNet.lnk
echo Installed executable: "%INSTALL_DIR%\ChessNet.exe"
echo.
echo Players can now double-click ChessNet from the Desktop.
exit /b 0

:fail
echo [ChessNet Install] Install failed.
pause
exit /b 1
