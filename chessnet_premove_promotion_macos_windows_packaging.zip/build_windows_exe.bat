@echo off
rem Compatibility wrapper. The project now uses fast one-folder packaging.
call "%~dp0build_windows_app.bat"
